package pacotesjava;
import java.util.Map;
public class TipoDaResposta {
    public String result;
    public String base_code;
    public Map<String, Double> conversion_rates;
}